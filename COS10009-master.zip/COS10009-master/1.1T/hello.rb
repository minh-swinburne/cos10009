# Put your code here:
def main()
  puts "Hello World"
end

main()
